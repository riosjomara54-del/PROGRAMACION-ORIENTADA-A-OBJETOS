# Clima Promedio Semanal

Este repositorio contiene dos implementaciones en Python:
- Programación Tradicional
- Programación Orientada a Objetos (POO)

Incluye una comparación entre ambos paradigmas.
