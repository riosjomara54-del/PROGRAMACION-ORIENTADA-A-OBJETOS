# Programa: Promedio semanal del clima
# Paradigma: Programación Orientada a Objetos (POO)

class Clima:
    def __init__(self, temperatura):
        self.__temperatura = temperatura  # Encapsulamiento

    def get_temperatura(self):
        return self.__temperatura

class ClimaSemanal:
    def __init__(self):
        self.dias = []

    def ingresar_datos(self):
        for dia in range(1, 8):
            temp = float(input(f"Ingrese la temperatura del día {dia}: "))
            self.dias.append(Clima(temp))

    def calcular_promedio(self):
        total = sum(dia.get_temperatura() for dia in self.dias)
        return total / len(self.dias)

print("Registro de temperaturas semanales (POO)")
clima = ClimaSemanal()
clima.ingresar_datos()
promedio = clima.calcular_promedio()
print(f"El promedio semanal de temperatura es: {promedio:.2f} °C")
