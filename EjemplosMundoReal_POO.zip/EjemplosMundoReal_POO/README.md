
# EjemplosMundoReal_POO

## Descripción del caso (Mundo Real)
Este ejemplo modela un **Sistema de Reservas de Hotel** utilizando Programación Orientada a Objetos (POO).
El sistema permite:
- Crear clientes
- Crear habitaciones
- Realizar reservas
- Mostrar información de reservas

Se aplican los principios de POO mediante:
- Clases
- Atributos
- Métodos
- Interacción entre objetos

Este directorio debe subirse a tu repositorio de GitHub como evidencia del trabajo solicitado.
