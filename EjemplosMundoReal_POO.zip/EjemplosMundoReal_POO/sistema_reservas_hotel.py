
# Ejemplo de Programación Orientada a Objetos
# Caso del Mundo Real: Sistema de Reservas de Hotel

class Cliente:
    def __init__(self, nombre, cedula):
        self.nombre = nombre
        self.cedula = cedula

    def __str__(self):
        return f"Cliente: {self.nombre} - Cédula: {self.cedula}"


class Habitacion:
    def __init__(self, numero, tipo, precio):
        self.numero = numero
        self.tipo = tipo
        self.precio = precio
        self.disponible = True

    def __str__(self):
        estado = "Disponible" if self.disponible else "Ocupada"
        return f"Habitación {self.numero} | Tipo: {self.tipo} | Precio: ${self.precio} | {estado}"


class Reserva:
    def __init__(self, cliente, habitacion, dias):
        self.cliente = cliente
        self.habitacion = habitacion
        self.dias = dias
        self.total = self.calcular_total()
        self.habitacion.disponible = False

    def calcular_total(self):
        return self.habitacion.precio * self.dias

    def mostrar_reserva(self):
        print("=== DETALLE DE RESERVA ===")
        print(self.cliente)
        print(self.habitacion)
        print(f"Días: {self.dias}")
        print(f"Total a pagar: ${self.total}")


# Bloque principal de ejecución
if __name__ == "__main__":
    # Crear objetos del sistema
    cliente1 = Cliente("Juan Pérez", "0102030405")
    habitacion1 = Habitacion(101, "Simple", 35)

    # Mostrar información inicial
    print(habitacion1)

    # Crear una reserva
    reserva1 = Reserva(cliente1, habitacion1, 3)

    # Mostrar resultado
    reserva1.mostrar_reserva()
