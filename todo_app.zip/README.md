# Aplicación GUI Lista de Tareas (Tkinter)

## Descripción
Aplicación simple hecha en Python con Tkinter para gestionar tareas.

## Funciones
- Añadir tareas (botón o Enter)
- Marcar como completadas (botón o doble clic)
- Eliminar tareas

## Cómo ejecutar
1. Abrir el proyecto en PyCharm
2. Ejecutar main.py

## Autor
Estudiante
