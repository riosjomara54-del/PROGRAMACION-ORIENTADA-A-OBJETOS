import tkinter as tk
from tkinter import messagebox

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lista de Tareas")

        self.tasks = []

        # Entry
        self.entry = tk.Entry(root, width=40)
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", self.add_task_event)

        # Listbox
        self.listbox = tk.Listbox(root, width=50, height=10)
        self.listbox.pack(pady=10)

        # Buttons
        frame = tk.Frame(root)
        frame.pack()

        tk.Button(frame, text="Añadir Tarea", command=self.add_task).grid(row=0, column=0, padx=5)
        tk.Button(frame, text="Marcar como Completada", command=self.complete_task).grid(row=0, column=1, padx=5)
        tk.Button(frame, text="Eliminar Tarea", command=self.delete_task).grid(row=0, column=2, padx=5)

        # Double click event
        self.listbox.bind("<Double-Button-1>", self.complete_task_event)

    def add_task(self):
        task = self.entry.get().strip()
        if task == "":
            messagebox.showwarning("Advertencia", "Escribe una tarea")
            return

        self.tasks.append({"text": task, "completed": False})
        self.update_listbox()
        self.entry.delete(0, tk.END)

    def add_task_event(self, event):
        self.add_task()

    def complete_task(self):
        try:
            index = self.listbox.curselection()[0]
            self.tasks[index]["completed"] = True
            self.update_listbox()
        except IndexError:
            messagebox.showwarning("Advertencia", "Selecciona una tarea")

    def complete_task_event(self, event):
        self.complete_task()

    def delete_task(self):
        try:
            index = self.listbox.curselection()[0]
            self.tasks.pop(index)
            self.update_listbox()
        except IndexError:
            messagebox.showwarning("Advertencia", "Selecciona una tarea")

    def update_listbox(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            text = task["text"]
            if task["completed"]:
                text += " ✔"
            self.listbox.insert(tk.END, text)


if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
