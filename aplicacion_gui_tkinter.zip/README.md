
# Aplicación GUI Básica con Tkinter

## Descripción
Este proyecto consiste en una aplicación básica de interfaz gráfica de usuario (GUI) desarrollada en Python utilizando la librería Tkinter.

La aplicación permite:
- Ingresar información mediante un campo de texto.
- Agregar la información a una lista visible en la interfaz.
- Eliminar elementos seleccionados de la lista.

## Componentes utilizados
La interfaz gráfica incluye:

- Label: muestra instrucciones al usuario.
- Entry: campo de texto para ingresar datos.
- Button: botones para agregar y limpiar información.
- Listbox: lista para mostrar los datos ingresados.

## Funcionalidades

### Agregar
El usuario escribe un dato en el campo de texto y presiona el botón **Agregar**.
El dato se añade a la lista.

### Limpiar
El usuario selecciona un elemento de la lista y presiona **Limpiar Selección** para eliminarlo.

## Eventos
La aplicación responde a los siguientes eventos:

- Clic en botón Agregar
- Clic en botón Limpiar Selección

## Librería utilizada
Tkinter (incluida por defecto en Python).

## Cómo ejecutar el programa

1. Tener instalado Python 3
2. Descargar el proyecto
3. Ejecutar el archivo:

python main.py

## Estructura del proyecto

aplicacion_gui_tkinter/
│
├── main.py
├── README.md
└── .gitignore

## Autor
Proyecto realizado como tarea académica para practicar el desarrollo de interfaces gráficas con Tkinter.
