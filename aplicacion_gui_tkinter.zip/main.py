
"""
Aplicación GUI Básica con Tkinter
Autor: Estudiante

Descripción:
Esta aplicación permite ingresar texto mediante un campo de entrada
y agregarlo a una lista visible dentro de la interfaz gráfica.
También incluye un botón para limpiar la información seleccionada.
"""

import tkinter as tk
from tkinter import messagebox

class AplicacionGUI:
    def __init__(self, root):
        """
        Constructor de la aplicación.
        Aquí se definen los componentes de la interfaz.
        """
        self.root = root
        self.root.title("Gestor Simple de Datos")

        # ----- Etiqueta de instrucción -----
        self.label = tk.Label(root, text="Ingrese un dato:")
        self.label.pack(pady=5)

        # ----- Campo de texto -----
        self.entry_dato = tk.Entry(root, width=40)
        self.entry_dato.pack(pady=5)

        # ----- Botón agregar -----
        self.boton_agregar = tk.Button(root, text="Agregar", command=self.agregar_dato)
        self.boton_agregar.pack(pady=5)

        # ----- Lista para mostrar datos -----
        self.lista_datos = tk.Listbox(root, width=50, height=10)
        self.lista_datos.pack(pady=10)

        # ----- Botón limpiar -----
        self.boton_limpiar = tk.Button(root, text="Limpiar Selección", command=self.limpiar_dato)
        self.boton_limpiar.pack(pady=5)

    def agregar_dato(self):
        """
        Evento que se ejecuta cuando el usuario presiona el botón 'Agregar'.
        Toma el texto del campo de entrada y lo agrega a la lista.
        """
        dato = self.entry_dato.get()

        if dato.strip() == "":
            messagebox.showwarning("Advertencia", "Debe ingresar un dato.")
            return

        self.lista_datos.insert(tk.END, dato)
        self.entry_dato.delete(0, tk.END)

    def limpiar_dato(self):
        """
        Elimina el elemento seleccionado de la lista.
        """
        seleccion = self.lista_datos.curselection()

        if not seleccion:
            messagebox.showinfo("Información", "Seleccione un elemento para eliminar.")
            return

        self.lista_datos.delete(seleccion)

if __name__ == "__main__":
    root = tk.Tk()
    app = AplicacionGUI(root)
    root.mainloop()
