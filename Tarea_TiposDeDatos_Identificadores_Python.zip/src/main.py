"""
Programa: Conversor de Unidades (Celsius a Fahrenheit)

Descripción:
Este programa convierte una temperatura ingresada en grados Celsius a grados Fahrenheit.
Demuestra el uso de tipos de datos básicos en Python (int, float, string, boolean),
así como el uso de identificadores descriptivos en snake_case.
"""

def convertir_celsius_a_fahrenheit(temperatura_celsius: float) -> float:
    """
    Convierte una temperatura de Celsius a Fahrenheit.
    """
    return (temperatura_celsius * 9 / 5) + 32


def main():
    # Solicitar datos al usuario (string)
    nombre_usuario = input("Ingrese su nombre: ")

    # Entrada de datos numéricos (float)
    temperatura_celsius = float(input("Ingrese la temperatura en grados Celsius: "))

    # Conversión de temperatura
    temperatura_fahrenheit = convertir_celsius_a_fahrenheit(temperatura_celsius)

    # Uso de boolean
    es_temperatura_alta = temperatura_celsius > 30

    # Salida de resultados
    print(f"Hola {nombre_usuario}, la temperatura en Fahrenheit es: {temperatura_fahrenheit:.2f}")

    if es_temperatura_alta:
        print("La temperatura es considerada alta.")
    else:
        print("La temperatura no es considerada alta.")


if __name__ == "__main__":
    main()
