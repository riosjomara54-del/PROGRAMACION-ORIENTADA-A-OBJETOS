# Tarea: Tipos de Datos e Identificadores en Python

## Descripción
Este proyecto contiene un programa sencillo en Python que convierte una temperatura de grados Celsius a Fahrenheit.
Fue desarrollado en PyCharm y está listo para ser publicado en GitHub.

## Contenidos
- `src/main.py`: Programa principal en Python.
- Uso de tipos de datos: integer, float, string y boolean.
- Identificadores descriptivos usando la convención `snake_case`.

## Ejecución
1. Abrir el proyecto en PyCharm.
2. Ejecutar el archivo `main.py`.
3. Ingresar los datos solicitados por el programa.

## Autor
Estudiante
