
AGENDA PERSONAL - TKINTER

Aplicación GUI desarrollada en Python con Tkinter.

Funciones:
- Agregar eventos
- Visualizar eventos en una tabla
- Eliminar eventos con confirmación

Instalación:

pip install tkcalendar

Ejecutar:

python main.py
