
"""
Aplicación de Agenda Personal con Tkinter
Permite agregar, visualizar y eliminar eventos con fecha, hora y descripción.

Requisitos externos:
pip install tkcalendar
"""

import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry

class AgendaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Agenda Personal")
        self.root.geometry("600x400")

        # Frame de visualización
        frame_lista = tk.Frame(root)
        frame_lista.pack(pady=10, padx=10, fill="both", expand=True)

        columnas = ("Fecha", "Hora", "Descripción")
        self.tree = ttk.Treeview(frame_lista, columns=columnas, show="headings")

        for col in columnas:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center")

        self.tree.pack(fill="both", expand=True)

        # Frame de entrada
        frame_entrada = tk.Frame(root)
        frame_entrada.pack(pady=10)

        tk.Label(frame_entrada, text="Fecha:").grid(row=0, column=0, padx=5, pady=5)
        self.fecha_entry = DateEntry(frame_entrada, width=12)
        self.fecha_entry.grid(row=0, column=1, padx=5)

        tk.Label(frame_entrada, text="Hora:").grid(row=0, column=2, padx=5)
        self.hora_entry = tk.Entry(frame_entrada, width=10)
        self.hora_entry.grid(row=0, column=3, padx=5)

        tk.Label(frame_entrada, text="Descripción:").grid(row=0, column=4, padx=5)
        self.desc_entry = tk.Entry(frame_entrada, width=25)
        self.desc_entry.grid(row=0, column=5, padx=5)

        # Frame de botones
        frame_botones = tk.Frame(root)
        frame_botones.pack(pady=10)

        btn_agregar = tk.Button(frame_botones, text="Agregar Evento", command=self.agregar_evento)
        btn_agregar.grid(row=0, column=0, padx=10)

        btn_eliminar = tk.Button(frame_botones, text="Eliminar Evento Seleccionado", command=self.eliminar_evento)
        btn_eliminar.grid(row=0, column=1, padx=10)

        btn_salir = tk.Button(frame_botones, text="Salir", command=root.quit)
        btn_salir.grid(row=0, column=2, padx=10)

    def agregar_evento(self):
        fecha = self.fecha_entry.get()
        hora = self.hora_entry.get()
        descripcion = self.desc_entry.get()

        if not hora or not descripcion:
            messagebox.showwarning("Campos vacíos", "Por favor completa todos los campos.")
            return

        self.tree.insert("", "end", values=(fecha, hora, descripcion))

        self.hora_entry.delete(0, tk.END)
        self.desc_entry.delete(0, tk.END)

    def eliminar_evento(self):
        seleccionado = self.tree.selection()

        if not seleccionado:
            messagebox.showwarning("Selecciona un evento", "Debes seleccionar un evento para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar", "¿Seguro que deseas eliminar este evento?")

        if confirmar:
            for item in seleccionado:
                self.tree.delete(item)


if __name__ == "__main__":
    root = tk.Tk()
    app = AgendaApp(root)
    root.mainloop()
