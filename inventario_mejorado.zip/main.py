"""
Sistema de Gestión de Inventarios Mejorado
Autor: Jomara Rios
"""

import os

ARCHIVO_INVENTARIO = "inventario.txt"


class Producto:
    def __init__(self, id_producto, nombre, cantidad, precio):
        self.id_producto = id_producto
        self.nombre = nombre
        self.cantidad = cantidad
        self.precio = precio

    def __str__(self):
        return f"ID: {self.id_producto} | Nombre: {self.nombre} | Cantidad: {self.cantidad} | Precio: ${self.precio:.2f}"

    def to_file_string(self):
        return f"{self.id_producto},{self.nombre},{self.cantidad},{self.precio}\n"


class Inventario:
    def __init__(self, archivo):
        self.archivo = archivo
        self.productos = {}
        self.cargar_desde_archivo()

    def cargar_desde_archivo(self):
        try:
            if not os.path.exists(self.archivo):
                with open(self.archivo, "w", encoding="utf-8"):
                    pass
                print("Archivo de inventario creado automáticamente.")

            with open(self.archivo, "r", encoding="utf-8") as f:
                for linea in f:
                    try:
                        id_producto, nombre, cantidad, precio = linea.strip().split(",")
                        self.productos[id_producto] = Producto(
                            id_producto, nombre, int(cantidad), float(precio)
                        )
                    except ValueError:
                        print("Advertencia: Línea corrupta ignorada.")

        except PermissionError:
            print("Error: No tienes permisos para leer el archivo.")
        except Exception as e:
            print(f"Error inesperado: {e}")

    def guardar_en_archivo(self):
        try:
            with open(self.archivo, "w", encoding="utf-8") as f:
                for producto in self.productos.values():
                    f.write(producto.to_file_string())
            print("Cambios guardados correctamente.")
        except PermissionError:
            print("Error: No tienes permisos para escribir en el archivo.")
        except Exception as e:
            print(f"Error inesperado: {e}")

    def agregar_producto(self, producto):
        if producto.id_producto in self.productos:
            print("Error: Ya existe un producto con ese ID.")
        else:
            self.productos[producto.id_producto] = producto
            self.guardar_en_archivo()
            print("Producto agregado exitosamente.")

    def actualizar_producto(self, id_producto, cantidad, precio):
        if id_producto in self.productos:
            self.productos[id_producto].cantidad = cantidad
            self.productos[id_producto].precio = precio
            self.guardar_en_archivo()
            print("Producto actualizado exitosamente.")
        else:
            print("Error: Producto no encontrado.")

    def eliminar_producto(self, id_producto):
        if id_producto in self.productos:
            del self.productos[id_producto]
            self.guardar_en_archivo()
            print("Producto eliminado exitosamente.")
        else:
            print("Error: Producto no encontrado.")

    def mostrar_productos(self):
        if not self.productos:
            print("Inventario vacío.")
        else:
            for producto in self.productos.values():
                print(producto)


def menu():
    inventario = Inventario(ARCHIVO_INVENTARIO)

    while True:
        print("\n===== SISTEMA DE INVENTARIO =====")
        print("1. Mostrar productos")
        print("2. Agregar producto")
        print("3. Actualizar producto")
        print("4. Eliminar producto")
        print("5. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            inventario.mostrar_productos()

        elif opcion == "2":
            try:
                id_producto = input("ID: ")
                nombre = input("Nombre: ")
                cantidad = int(input("Cantidad: "))
                precio = float(input("Precio: "))
                producto = Producto(id_producto, nombre, cantidad, precio)
                inventario.agregar_producto(producto)
            except ValueError:
                print("Error: Cantidad debe ser entero y precio debe ser decimal.")

        elif opcion == "3":
            try:
                id_producto = input("ID del producto a actualizar: ")
                cantidad = int(input("Nueva cantidad: "))
                precio = float(input("Nuevo precio: "))
                inventario.actualizar_producto(id_producto, cantidad, precio)
            except ValueError:
                print("Error: Datos inválidos.")

        elif opcion == "4":
            id_producto = input("ID del producto a eliminar: ")
            inventario.eliminar_producto(id_producto)

        elif opcion == "5":
            print("Saliendo del sistema...")
            break
        else:
            print("Opción inválida.")


if __name__ == "__main__":
    menu()
