# 📦 Sistema de Gestión de Inventarios Mejorado

## 📌 Descripción
Sistema en Python que permite:
- Agregar productos
- Actualizar productos
- Eliminar productos
- Mostrar productos
- Guardar datos en archivo inventario.txt
- Cargar datos automáticamente al iniciar

## 🛡 Manejo de Excepciones
- Crea el archivo si no existe
- Maneja PermissionError
- Ignora líneas corruptas
- Captura ValueError en entradas inválidas

## ▶️ Ejecutar
python main.py

## 👩‍💻 Autor
Jomara Rios
