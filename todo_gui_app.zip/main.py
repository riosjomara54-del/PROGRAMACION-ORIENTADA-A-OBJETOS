import tkinter as tk
from tkinter import messagebox

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestión de Tareas")

        self.tasks = []

        # Entry
        self.entry = tk.Entry(root, width=40)
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", lambda event: self.add_task())

        # Buttons
        frame = tk.Frame(root)
        frame.pack()

        tk.Button(frame, text="Añadir", command=self.add_task).grid(row=0, column=0, padx=5)
        tk.Button(frame, text="Completar", command=self.complete_task).grid(row=0, column=1, padx=5)
        tk.Button(frame, text="Eliminar", command=self.delete_task).grid(row=0, column=2, padx=5)

        # Listbox
        self.listbox = tk.Listbox(root, width=50, height=10)
        self.listbox.pack(pady=10)

        # Keyboard shortcuts
        self.root.bind("c", lambda event: self.complete_task())
        self.root.bind("C", lambda event: self.complete_task())
        self.root.bind("<Delete>", lambda event: self.delete_task())
        self.root.bind("d", lambda event: self.delete_task())
        self.root.bind("<Escape>", lambda event: self.root.quit())

    def add_task(self):
        task = self.entry.get().strip()
        if task:
            self.tasks.append({"text": task, "completed": False})
            self.update_list()
            self.entry.delete(0, tk.END)

    def complete_task(self):
        try:
            index = self.listbox.curselection()[0]
            self.tasks[index]["completed"] = True
            self.update_list()
        except IndexError:
            messagebox.showwarning("Aviso", "Selecciona una tarea")

    def delete_task(self):
        try:
            index = self.listbox.curselection()[0]
            self.tasks.pop(index)
            self.update_list()
        except IndexError:
            messagebox.showwarning("Aviso", "Selecciona una tarea")

    def update_list(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            text = task["text"]
            if task["completed"]:
                text += " ✔"
            self.listbox.insert(tk.END, text)

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
