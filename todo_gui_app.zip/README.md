# Aplicación GUI de Gestión de Tareas

Aplicación desarrollada con Python y Tkinter que permite gestionar tareas.

## Funcionalidades

- Añadir tareas (botón o Enter)
- Marcar como completadas (botón o tecla C)
- Eliminar tareas (botón o tecla Delete o D)
- Salir con tecla Escape

## Cómo ejecutar

```bash
python main.py
```
