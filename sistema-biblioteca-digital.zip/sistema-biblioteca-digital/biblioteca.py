# biblioteca.py
# Sistema de Gestión de Biblioteca Digital
# Se aplican colecciones: listas, tuplas, diccionarios y conjuntos

class Libro:
    def __init__(self, titulo, autor, categoria, isbn):
        self.info = (titulo, autor)  # Tupla inmutable
        self.categoria = categoria
        self.isbn = isbn

    def __str__(self):
        return f"Título: {self.info[0]}, Autor: {self.info[1]}, Categoría: {self.categoria}, ISBN: {self.isbn}"


class Usuario:
    def __init__(self, nombre, user_id):
        self.nombre = nombre
        self.user_id = user_id
        self.libros_prestados = []  # Lista

    def __str__(self):
        return f"Usuario: {self.nombre}, ID: {self.user_id}"


class Biblioteca:
    def __init__(self):
        self.libros_disponibles = {}  # Diccionario {ISBN: Libro}
        self.usuarios_registrados = {}  # Diccionario {ID: Usuario}
        self.ids_usuarios = set()  # Conjunto para IDs únicos

    def agregar_libro(self, libro):
        if libro.isbn in self.libros_disponibles:
            print("El libro ya existe en la biblioteca.")
        else:
            self.libros_disponibles[libro.isbn] = libro
            print("Libro agregado correctamente.")

    def quitar_libro(self, isbn):
        if isbn in self.libros_disponibles:
            del self.libros_disponibles[isbn]
            print("Libro eliminado correctamente.")
        else:
            print("Libro no encontrado.")

    def registrar_usuario(self, usuario):
        if usuario.user_id in self.ids_usuarios:
            print("El ID ya está registrado.")
        else:
            self.ids_usuarios.add(usuario.user_id)
            self.usuarios_registrados[usuario.user_id] = usuario
            print("Usuario registrado correctamente.")

    def dar_baja_usuario(self, user_id):
        if user_id in self.ids_usuarios:
            del self.usuarios_registrados[user_id]
            self.ids_usuarios.remove(user_id)
            print("Usuario eliminado correctamente.")
        else:
            print("Usuario no encontrado.")

    def prestar_libro(self, isbn, user_id):
        if isbn not in self.libros_disponibles:
            print("Libro no disponible.")
            return

        if user_id not in self.usuarios_registrados:
            print("Usuario no registrado.")
            return

        libro = self.libros_disponibles.pop(isbn)
        self.usuarios_registrados[user_id].libros_prestados.append(libro)
        print("Libro prestado correctamente.")

    def devolver_libro(self, isbn, user_id):
        if user_id not in self.usuarios_registrados:
            print("Usuario no registrado.")
            return

        usuario = self.usuarios_registrados[user_id]

        for libro in usuario.libros_prestados:
            if libro.isbn == isbn:
                usuario.libros_prestados.remove(libro)
                self.libros_disponibles[isbn] = libro
                print("Libro devuelto correctamente.")
                return

        print("El usuario no tiene ese libro.")

    def buscar_por_titulo(self, titulo):
        return [libro for libro in self.libros_disponibles.values()
                if libro.info[0].lower() == titulo.lower()]

    def buscar_por_autor(self, autor):
        return [libro for libro in self.libros_disponibles.values()
                if libro.info[1].lower() == autor.lower()]

    def buscar_por_categoria(self, categoria):
        return [libro for libro in self.libros_disponibles.values()
                if libro.categoria.lower() == categoria.lower()]

    def listar_libros_prestados(self, user_id):
        if user_id in self.usuarios_registrados:
            return self.usuarios_registrados[user_id].libros_prestados
        else:
            print("Usuario no encontrado.")
            return []
