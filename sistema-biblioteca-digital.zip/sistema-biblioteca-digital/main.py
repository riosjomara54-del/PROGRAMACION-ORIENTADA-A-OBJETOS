# main.py
from biblioteca import Libro, Usuario, Biblioteca

biblioteca = Biblioteca()

libro1 = Libro("Cien Años de Soledad", "Gabriel García Márquez", "Novela", "111")
libro2 = Libro("1984", "George Orwell", "Distopía", "222")
libro3 = Libro("El Principito", "Antoine de Saint-Exupéry", "Infantil", "333")

biblioteca.agregar_libro(libro1)
biblioteca.agregar_libro(libro2)
biblioteca.agregar_libro(libro3)

usuario1 = Usuario("Ana Torres", "U001")
usuario2 = Usuario("Luis Pérez", "U002")

biblioteca.registrar_usuario(usuario1)
biblioteca.registrar_usuario(usuario2)

biblioteca.prestar_libro("111", "U001")

print("\nLibros prestados a Ana:")
for libro in biblioteca.listar_libros_prestados("U001"):
    print(libro)

biblioteca.devolver_libro("111", "U001")

print("\nLibros categoría Distopía:")
for libro in biblioteca.buscar_por_categoria("Distopía"):
    print(libro)
