# 📚 Sistema de Gestión de Biblioteca Digital

## 📌 Descripción
Este proyecto implementa un sistema de gestión de biblioteca digital utilizando Programación Orientada a Objetos en Python.

## 🛠 Tecnologías utilizadas
- Python
- Programación Orientada a Objetos
- Colecciones: listas, tuplas, diccionarios y conjuntos

## 📂 Estructura del Proyecto
- biblioteca.py → Contiene las clases principales.
- main.py → Archivo de prueba del sistema.

## ▶ Cómo ejecutar
1. Asegúrate de tener Python instalado.
2. Ejecuta el archivo main.py:

   python main.py

## 👩‍💻 Autor
Proyecto académico - Sistema de Gestión de Biblioteca Digital.
