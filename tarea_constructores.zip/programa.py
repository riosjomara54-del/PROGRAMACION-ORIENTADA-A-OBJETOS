
# Programa de ejemplo sobre constructores y destructores en Python

class ArchivoManager:
    def __init__(self, nombre):
        # Constructor
        self.nombre = nombre
        self.archivo = open(nombre, 'w')
        print(f"Constructor: archivo '{nombre}' creado y abierto.")

    def escribir(self, texto):
        self.archivo.write(texto + "\n")

    def __del__(self):
        # Destructor
        try:
            self.archivo.close()
            print(f"Destructor: archivo '{self.nombre}' cerrado correctamente.")
        except Exception:
            pass


def main():
    gestor = ArchivoManager("salida.txt")
    gestor.escribir("Hola, este es un ejemplo de constructores y destructores.")
    gestor.escribir("Al terminar el programa, el destructor cerrará el archivo automáticamente.")

if __name__ == "__main__":
    main()
