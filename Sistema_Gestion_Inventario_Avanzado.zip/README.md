
# Sistema Avanzado de Gestión de Inventario

## Descripción
Sistema desarrollado en Python utilizando Programación Orientada a Objetos (POO), colecciones y almacenamiento en archivos JSON.

## Estructura del Proyecto
- producto.py → Clase Producto
- inventario.py → Clase Inventario
- main.py → Interfaz de usuario en consola
- inventario.json → Archivo generado automáticamente para persistencia

## Uso de Colecciones
Se utiliza un diccionario para almacenar los productos usando el ID como clave.
Esto permite:
- Búsqueda rápida (O(1))
- Eliminación eficiente
- Actualización directa por ID

También se emplean listas para búsquedas por nombre.

## Almacenamiento en Archivos
Se utiliza el módulo json para serializar y deserializar los datos del inventario.
- guardar_en_archivo() → Convierte los objetos en diccionarios y los guarda en JSON.
- cargar_desde_archivo() → Reconstruye los objetos Producto desde el archivo.

## Cómo Ejecutar
1. Abrir el proyecto en PyCharm.
2. Ejecutar main.py.
3. Usar el menú interactivo.

## Autor
Jomara Rios
