
import json
from producto import Producto

class Inventario:
    def __init__(self):
        # Diccionario para acceso rápido por ID
        self.productos = {}

    def añadir_producto(self, producto):
        if producto.get_id() in self.productos:
            print("Error: El producto ya existe.")
        else:
            self.productos[producto.get_id()] = producto
            print("Producto añadido correctamente.")

    def eliminar_producto(self, id_producto):
        if id_producto in self.productos:
            del self.productos[id_producto]
            print("Producto eliminado correctamente.")
        else:
            print("Producto no encontrado.")

    def actualizar_producto(self, id_producto, cantidad=None, precio=None):
        if id_producto in self.productos:
            if cantidad is not None:
                self.productos[id_producto].set_cantidad(cantidad)
            if precio is not None:
                self.productos[id_producto].set_precio(precio)
            print("Producto actualizado correctamente.")
        else:
            print("Producto no encontrado.")

    def buscar_por_nombre(self, nombre):
        encontrados = [p for p in self.productos.values() if nombre.lower() in p.get_nombre().lower()]
        return encontrados

    def mostrar_todos(self):
        if not self.productos:
            print("Inventario vacío.")
        for producto in self.productos.values():
            print(producto.to_dict())

    def guardar_en_archivo(self, archivo):
        with open(archivo, "w", encoding="utf-8") as f:
            json.dump([p.to_dict() for p in self.productos.values()], f, indent=4)
        print("Inventario guardado correctamente.")

    def cargar_desde_archivo(self, archivo):
        try:
            with open(archivo, "r", encoding="utf-8") as f:
                datos = json.load(f)
                for item in datos:
                    producto = Producto.from_dict(item)
                    self.productos[producto.get_id()] = producto
            print("Inventario cargado correctamente.")
        except FileNotFoundError:
            print("Archivo no encontrado. Se creará uno nuevo al guardar.")
