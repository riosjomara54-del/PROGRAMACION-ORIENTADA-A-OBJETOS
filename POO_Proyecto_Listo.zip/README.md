# Proyecto POO Personalizado

Este repositorio contiene una versión personalizada del proyecto de Programación Orientada a Objetos.

Incluye:

- Archivo `Dashboard.py` personalizado.
- Estructura lista para subir a GitHub.

Sube esta carpeta a tu repositorio personal.