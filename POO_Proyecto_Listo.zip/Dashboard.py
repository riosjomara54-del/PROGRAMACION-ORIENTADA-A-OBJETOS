# Dashboard personalizado para gestión de tareas POO
# Autor: jomara rios
# Descripción: Interfaz simple para organizar tareas del curso.

class Dashboard:
    def __init__(self):
        self.tareas = []

    def agregar_tarea(self, nombre, fecha, estado="Pendiente"):
        self.tareas.append({
            "nombre": nombre,
            "fecha": fecha,
            "estado": estado
        })

    def mostrar_tareas(self):
        print("=== TAREAS REGISTRADAS ===")
        for t in self.tareas:
            print(f"Tarea: {t['nombre']} | Fecha: {t['fecha']} | Estado: {t['estado']}")

    def actualizar_estado(self, nombre, nuevo_estado):
        for t in self.tareas:
            if t["nombre"] == nombre:
                t["estado"] = nuevo_estado
                return True
        return False

# Ejemplo de uso
if __name__ == "__main__":
    dash = Dashboard()
    dash.agregar_tarea("Proyecto POO", "2026-02-01")
    dash.agregar_tarea("Lectura Capítulo 3", "2026-01-30")
    dash.mostrar_tareas()
