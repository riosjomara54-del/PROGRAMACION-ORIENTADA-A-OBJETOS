# Sistema de Gestión de Inventarios

Proyecto desarrollado en Python usando Programación Orientada a Objetos.

## Funcionalidades
- Añadir productos
- Eliminar productos por ID
- Actualizar cantidad o precio
- Buscar productos por nombre
- Mostrar todos los productos

## Ejecución
Ejecutar el archivo main.py desde PyCharm o la consola.
