# main.py
# Programa principal con menú interactivo

from producto import Producto
from inventario import Inventario

inventario = Inventario()

def menu():
    print("\n--- SISTEMA DE GESTIÓN DE INVENTARIOS ---")
    print("1. Añadir producto")
    print("2. Eliminar producto")
    print("3. Actualizar producto")
    print("4. Buscar producto por nombre")
    print("5. Mostrar todos los productos")
    print("6. Salir")

while True:
    menu()
    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        id_producto = int(input("ID: "))
        nombre = input("Nombre: ")
        cantidad = int(input("Cantidad: "))
        precio = float(input("Precio: "))
        producto = Producto(id_producto, nombre, cantidad, precio)
        inventario.añadir_producto(producto)

    elif opcion == "2":
        id_producto = int(input("Ingrese el ID del producto a eliminar: "))
        inventario.eliminar_producto(id_producto)

    elif opcion == "3":
        id_producto = int(input("Ingrese el ID del producto a actualizar: "))
        cantidad = input("Nueva cantidad (dejar vacío si no cambia): ")
        precio = input("Nuevo precio (dejar vacío si no cambia): ")
        nueva_cantidad = int(cantidad) if cantidad else None
        nuevo_precio = float(precio) if precio else None
        inventario.actualizar_producto(id_producto, nueva_cantidad, nuevo_precio)

    elif opcion == "4":
        nombre = input("Ingrese el nombre a buscar: ")
        resultados = inventario.buscar_por_nombre(nombre)
        if resultados:
            for p in resultados:
                print(p)
        else:
            print("No se encontraron productos.")

    elif opcion == "5":
        inventario.mostrar_todos()

    elif opcion == "6":
        print("Saliendo del sistema...")
        break

    else:
        print("Opción inválida.")
