from clases.vehiculo import Vehiculo

# Clase derivada que demuestra herencia y polimorfismo
class Coche(Vehiculo):
    def __init__(self, marca, motor, puertas):
        super().__init__(marca, motor)
        self.puertas = puertas

    # Polimorfismo mediante sobrescritura de método
    def descripcion(self):
        return f"Coche {self.get_marca()} con motor {self.get_motor()} y {self.puertas} puertas"
