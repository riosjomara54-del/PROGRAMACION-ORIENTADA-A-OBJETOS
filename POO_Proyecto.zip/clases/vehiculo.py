# Clase base demostrando encapsulación
class Vehiculo:
    def __init__(self, marca, motor):
        self._marca = marca      # Atributo encapsulado (protegido)
        self.__motor = motor     # Atributo encapsulado (privado)

    def descripcion(self):
        return f"Vehículo de marca {self._marca} con motor {self.__motor}"

    # Métodos getter para acceder al motor
    def get_marca(self):
        return self._marca

    def get_motor(self):
        return self.__motor
