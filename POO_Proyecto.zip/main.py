from clases.vehiculo import Vehiculo
from clases.coche import Coche

# Crear instancias
vehiculo = Vehiculo("Genérico", "Motor básico")
coche = Coche("Toyota", "Motor V8", 4)

# Mostrar descripción mediante polimorfismo
print(vehiculo.descripcion())
print(coche.descripcion())

# Acceder a atributos encapsulados mediante métodos públicos
print("Marca:", coche.get_marca())
print("Motor:", coche.get_motor())
